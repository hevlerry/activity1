from django.urls import path
from .views import ContactView, InquiryListView

urlpatterns = [
    path('contact/', ContactView.as_view(), name='contact'),
    path('inquiries/', InquiryListView.as_view(), name='inquiry-list'),
]
