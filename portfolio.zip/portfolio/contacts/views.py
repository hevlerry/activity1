from django.views.generic import FormView, ListView
from django.urls import reverse_lazy
from .forms import ContactForm
from .models import Contact
from django.contrib.auth.mixins import LoginRequiredMixin

class ContactView(FormView):
    template_name = 'contact.html'
    form_class = ContactForm
    success_url = reverse_lazy('contact')

    def form_valid(self, form):
        form.save()
        return super().form_valid(form)

class InquiryListView(LoginRequiredMixin, ListView):
    model = Contact
    template_name = 'inquiry_list.html'
    context_object_name = 'inquiries'
    login_url = 'login'
